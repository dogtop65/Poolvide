import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { NavHeader } from "@/components/nav-header";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import ProductDetails from "@/pages/product/[id]";
import TrendingPage from "@/pages/trending";
import FavoritesPage from "@/pages/favorites";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/product/:id" component={ProductDetails} />
      <Route path="/trending" component={TrendingPage} />
      <Route path="/favorites" component={FavoritesPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <NavHeader />
        <main className="flex-1">
          <Router />
        </main>
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;