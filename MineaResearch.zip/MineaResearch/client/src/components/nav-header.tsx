import { Link } from "wouter";
import { SiMinutemailer } from "react-icons/si";

export function NavHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <SiMinutemailer className="h-5 w-5" />
          <span>AdSpy Pro</span>
        </Link>
        
        <nav className="flex items-center space-x-6 ml-6">
          <Link href="/" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
            Dashboard
          </Link>
          <Link href="/favorites" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
            Favorites
          </Link>
          <Link href="/trending" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
            Trending
          </Link>
        </nav>
      </div>
    </header>
  );
}
