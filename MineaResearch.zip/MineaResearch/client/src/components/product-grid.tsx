import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, MousePointer, Calendar, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { Product } from "@shared/schema";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface ProductGridProps {
  products?: Product[];
  isLoading: boolean;
}

export function ProductGrid({ products, isLoading }: ProductGridProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get favorite products to check if a product is favorited
  const { data: favorites = [] } = useQuery({
    queryKey: ['/api/products/favorites']
  });

  const isFavorite = (productId: number) => {
    return favorites.some((p: Product) => p.id === productId);
  };

  const toggleFavorite = async (e: React.MouseEvent, productId: number, currentlyFavorited: boolean) => {
    e.preventDefault(); // Prevent triggering the Link click
    try {
      if (currentlyFavorited) {
        await apiRequest('DELETE', `/api/products/${productId}/favorite`);
        toast({ title: "Removed from favorites" });
      } else {
        await apiRequest('POST', `/api/products/${productId}/favorite`);
        toast({ title: "Added to favorites" });
      }
      // Invalidate favorites query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/products/favorites'] });
    } catch (error) {
      toast({ 
        title: "Error",
        description: "Failed to update favorites",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <div className="h-48 bg-muted rounded-t-lg" />
            <CardContent className="p-4">
              <div className="h-4 w-3/4 bg-muted rounded mb-2" />
              <div className="h-4 w-1/2 bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!products?.length) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No products found</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => {
        const favorited = isFavorite(product.id);
        return (
          <Card key={product.id} className="group relative overflow-hidden hover:shadow-xl transition-all duration-300">
            <div className="absolute top-4 right-4 z-10">
              <Button
                size="icon"
                variant="secondary"
                className={cn(
                  "bg-background/80 backdrop-blur-sm hover:bg-background",
                  favorited && "text-red-500 hover:text-red-600"
                )}
                onClick={(e) => toggleFavorite(e, product.id, favorited)}
              >
                <Heart className="h-4 w-4" fill={favorited ? "currentColor" : "none"} />
              </Button>
            </div>

            <Link href={`/product/${product.id}`}>
              <div className="relative">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="h-48 w-full object-cover rounded-t-lg transform group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute bottom-2 right-2 flex gap-2">
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    <Eye className="h-3 w-3 mr-1" />
                    {product.views.toLocaleString()}
                  </Badge>
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    <MousePointer className="h-3 w-3 mr-1" />
                    {product.clicks.toLocaleString()}
                  </Badge>
                </div>
              </div>

              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="bg-primary/5">
                    {product.platform}
                  </Badge>
                  <Badge variant="outline" className="bg-primary/5">
                    {product.category}
                  </Badge>
                </div>

                <h3 className="text-lg font-semibold mb-1 line-clamp-1 group-hover:text-primary transition-colors">
                  {product.title}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                  {product.description}
                </p>
              </CardContent>

              <CardFooter className="px-4 py-3 border-t flex justify-between items-center bg-muted/5">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="h-3 w-3 mr-1" />
                  {format(new Date(product.startDate), 'MMM d, yyyy')}
                </div>
                <p className="text-lg font-semibold text-primary">
                  ${(product.price / 100).toFixed(2)}
                </p>
              </CardFooter>
            </Link>
          </Card>
        );
      })}
    </div>
  );
}