import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Link } from "wouter";
import type { Product } from "@shared/schema";

interface ProductTableProps {
  products?: Product[];
  isLoading: boolean;
}

export function ProductTable({ products, isLoading }: ProductTableProps) {
  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="h-10 bg-muted rounded mb-4" />
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-16 bg-muted rounded mb-2" />
        ))}
      </div>
    );
  }

  if (!products?.length) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No products found</p>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Title</TableHead>
          <TableHead>Platform</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Price</TableHead>
          <TableHead>Views</TableHead>
          <TableHead>Clicks</TableHead>
          <TableHead>Start Date</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {products.map((product) => (
          <TableRow key={product.id}>
            <TableCell>
              <Link href={`/product/${product.id}`} className="hover:underline">
                {product.title}
              </Link>
            </TableCell>
            <TableCell>
              <Badge variant="secondary">{product.platform}</Badge>
            </TableCell>
            <TableCell>
              <Badge variant="secondary">{product.category}</Badge>
            </TableCell>
            <TableCell>${(product.price / 100).toFixed(2)}</TableCell>
            <TableCell>{product.views.toLocaleString()}</TableCell>
            <TableCell>{product.clicks.toLocaleString()}</TableCell>
            <TableCell>{format(new Date(product.startDate), 'PP')}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
