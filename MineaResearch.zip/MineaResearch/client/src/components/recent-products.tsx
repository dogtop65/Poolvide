import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Eye, MousePointer } from "lucide-react";
import { motion } from "framer-motion";
import type { Product } from "@shared/schema";

export function RecentProducts() {
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products/recent'],
  });

  if (isLoading) {
    return (
      <div className="flex gap-4 overflow-x-auto pb-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse flex-shrink-0 w-[300px]">
            <div className="h-40 bg-muted rounded-t-lg" />
            <CardContent className="p-4">
              <div className="h-4 w-3/4 bg-muted rounded mb-2" />
              <div className="h-4 w-1/2 bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!products?.length) {
    return (
      <div className="text-center py-4 text-muted-foreground">
        No recently viewed products
      </div>
    );
  }

  return (
    <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
      {products.map((product: Product, index) => (
        <motion.div
          key={product.id}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className="snap-start"
        >
          <Card className="flex-shrink-0 w-[300px] hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02]">
            <Link href={`/product/${product.id}`}>
              <div className="relative">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="h-40 w-full object-cover rounded-t-lg transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute bottom-2 right-2 flex gap-2">
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    <Eye className="h-3 w-3 mr-1" />
                    {product.views.toLocaleString()}
                  </Badge>
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    <MousePointer className="h-3 w-3 mr-1" />
                    {product.clicks.toLocaleString()}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2 line-clamp-1 transition-colors duration-300 hover:text-primary">{product.title}</h3>
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="bg-primary/5">
                    {product.platform}
                  </Badge>
                  <span className="font-semibold text-primary">
                    ${(product.price / 100).toFixed(2)}
                  </span>
                </div>
              </CardContent>
            </Link>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}