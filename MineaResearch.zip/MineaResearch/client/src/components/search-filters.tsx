import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, ArrowUpDown, SlidersHorizontal } from "lucide-react";
import type { SearchParams } from "@shared/schema";

interface SearchFiltersProps {
  params: SearchParams;
  onChange: (params: SearchParams) => void;
}

const PLATFORMS = ["Amazon", "Facebook", "Instagram", "TikTok"];
const CATEGORIES = ["Electronics", "Fashion", "Home", "Beauty"];
const SORT_OPTIONS = [
  { value: "views", label: "Most Viewed" },
  { value: "clicks", label: "Most Clicked" },
  { value: "date", label: "Latest" },
  { value: "price", label: "Price" }
];

export function SearchFilters({ params, onChange }: SearchFiltersProps) {
  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search products..."
          value={params.query || ""}
          onChange={(e) => onChange({ ...params, query: e.target.value || undefined })}
          className="pl-9 bg-background"
        />
      </div>

      {/* Filters Grid */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Select
          value={params.platform || "all"}
          onValueChange={(platform) => onChange({ 
            ...params, 
            platform: platform === "all" ? undefined : platform 
          })}
        >
          <SelectTrigger className="bg-background">
            <SelectValue placeholder="Select Platform" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Platforms</SelectItem>
            {PLATFORMS.map((platform) => (
              <SelectItem key={platform} value={platform}>
                {platform}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={params.category || "all"}
          onValueChange={(category) => onChange({ 
            ...params, 
            category: category === "all" ? undefined : category 
          })}
        >
          <SelectTrigger className="bg-background">
            <SelectValue placeholder="Select Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={params.sortBy || "none"}
          onValueChange={(sortBy) => onChange({ 
            ...params, 
            sortBy: sortBy === "none" ? undefined : sortBy as SearchParams['sortBy'],
            sortDir: sortBy === "none" ? undefined : "desc"
          })}
        >
          <SelectTrigger className="bg-background">
            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
              <SelectValue placeholder="Sort by" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No sorting</SelectItem>
            {SORT_OPTIONS.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}