import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SearchFilters } from "@/components/search-filters";
import { ProductGrid } from "@/components/product-grid";
import { ProductTable } from "@/components/product-table";
import { AnalyticsCards } from "@/components/analytics-cards";
import { RecentProducts } from "@/components/recent-products";
import type { SearchParams } from "@shared/schema";

export default function Dashboard() {
  const [searchParams, setSearchParams] = useState<SearchParams>({});

  const { data: products, isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products/search', searchParams],
    queryFn: async () => {
      const searchQuery = new URLSearchParams();

      if (searchParams.query) searchQuery.append('query', searchParams.query);
      if (searchParams.platform) searchQuery.append('platform', searchParams.platform);
      if (searchParams.category) searchQuery.append('category', searchParams.category);
      if (searchParams.sortBy) {
        searchQuery.append('sortBy', searchParams.sortBy);
        searchQuery.append('sortDir', searchParams.sortDir || 'desc');
      }

      const response = await fetch(`/api/products/search?${searchQuery}`);
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    }
  });

  const { data: analytics, isLoading: isLoadingAnalytics } = useQuery({
    queryKey: ['/api/analytics']
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        {/* Title Section */}
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Product Research</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Discover and analyze trending products across multiple platforms
          </p>
        </div>

        {/* Analytics Cards */}
        <AnalyticsCards data={analytics} isLoading={isLoadingAnalytics} />

        {/* Recently Viewed */}
        <div className="rounded-lg border bg-card">
          <div className="p-6">
            <h2 className="text-lg font-semibold mb-4">Recently Viewed</h2>
            <RecentProducts />
          </div>
        </div>

        {/* Search Section */}
        <div className="rounded-lg border bg-card">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Search & Filter</h2>
            </div>
            <SearchFilters 
              params={searchParams} 
              onChange={setSearchParams}
            />
          </div>
        </div>

        {/* Products Section */}
        <div className="rounded-lg border bg-card">
          <div className="p-6">
            <Tabs defaultValue="grid" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Products</h2>
                <TabsList>
                  <TabsTrigger value="grid">Grid View</TabsTrigger>
                  <TabsTrigger value="table">Table View</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="grid" className="mt-0">
                <ProductGrid products={products} isLoading={isLoadingProducts} />
              </TabsContent>

              <TabsContent value="table" className="mt-0">
                <ProductTable products={products} isLoading={isLoadingProducts} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}