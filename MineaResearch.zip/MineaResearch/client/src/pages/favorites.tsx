import { useQuery } from "@tanstack/react-query";
import { ProductGrid } from "@/components/product-grid";

export default function FavoritesPage() {
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products/favorites'],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Favorite Products</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            View and manage your saved products
          </p>
        </div>

        <div className="rounded-lg border bg-card">
          <div className="p-6">
            <ProductGrid products={products} isLoading={isLoading} />
          </div>
        </div>
      </div>
    </div>
  );
}
