import { useParams, Link } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Eye, MousePointer, Calendar, Heart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function ProductDetails() {
  const { id } = useParams();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery({
    queryKey: ['/api/products', id],
    queryFn: async () => {
      const response = await fetch(`/api/products/${id}`);
      if (!response.ok) throw new Error('Failed to fetch product');
      return response.json();
    }
  });

  const { data: favorites = [] } = useQuery({
    queryKey: ['/api/products/favorites']
  });

  const isFavorite = favorites.some((p: any) => p.id === Number(id));

  const toggleFavorite = async (isFavorite: boolean) => {
    try {
      if (isFavorite) {
        await apiRequest('DELETE', `/api/products/${id}/favorite`);
        toast({ title: "Removed from favorites" });
      } else {
        await apiRequest('POST', `/api/products/${id}/favorite`);
        toast({ title: "Added to favorites" });
      }
      // Invalidate favorites query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/products/favorites'] });
    } catch (error) {
      toast({ 
        title: "Error",
        description: "Failed to update favorites",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-32 bg-muted rounded" />
          <Card>
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="h-[400px] bg-muted rounded" />
                <div className="space-y-4">
                  <div className="h-8 w-3/4 bg-muted rounded" />
                  <div className="h-24 bg-muted rounded" />
                  <div className="h-8 w-1/2 bg-muted rounded" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto py-8">
        <Card className="p-6">
          <h1 className="text-2xl font-bold text-red-500">Product not found</h1>
          <p className="mt-2 text-muted-foreground">
            The product you're looking for doesn't exist or has been removed.
          </p>
          <Link href="/">
            <Button variant="outline" className="mt-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 max-w-6xl">
      <div className="flex items-center justify-between mb-6">
        <Link href="/">
          <Button variant="ghost" className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>
        <Button
          variant="outline"
          className={cn(
            "gap-2",
            isFavorite && "text-red-500 hover:text-red-600"
          )}
          onClick={() => toggleFavorite(isFavorite)}
        >
          <Heart className="h-4 w-4" fill={isFavorite ? "currentColor" : "none"} />
          {isFavorite ? "Remove from Favorites" : "Add to Favorites"}
        </Button>
      </div>

      <Card>
        <CardContent className="p-8">
          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-4">
              <div className="relative rounded-lg overflow-hidden">
                <img 
                  src={product.imageUrl} 
                  alt={product.title}
                  className="w-full aspect-4/3 object-cover"
                />
                <div className="absolute bottom-4 right-4 flex gap-2">
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    <Eye className="h-4 w-4 mr-2" />
                    {product.views.toLocaleString()}
                  </Badge>
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    <MousePointer className="h-4 w-4 mr-2" />
                    {product.clicks.toLocaleString()}
                  </Badge>
                </div>
              </div>

              <div className="flex gap-2">
                <Badge className="text-sm">{product.platform}</Badge>
                <Badge className="text-sm">{product.category}</Badge>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-4">{product.title}</h1>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center text-muted-foreground">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span>Campaign started on {format(new Date(product.startDate), 'MMMM d, yyyy')}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <Eye className="h-5 w-5 mr-2" />
                  <span>{product.views.toLocaleString()} Total Views</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <MousePointer className="h-5 w-5 mr-2" />
                  <span>{product.clicks.toLocaleString()} Total Clicks</span>
                </div>
              </div>

              <div className="pt-6 border-t">
                <div className="flex items-baseline gap-2">
                  <span className="text-sm text-muted-foreground">Price:</span>
                  <span className="text-3xl font-bold text-primary">
                    ${(product.price / 100).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}