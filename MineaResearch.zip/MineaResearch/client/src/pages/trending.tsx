import { useQuery } from "@tanstack/react-query";
import { ProductGrid } from "@/components/product-grid";

export default function TrendingPage() {
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products/trending'],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Trending Products</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Discover the most popular products right now
          </p>
        </div>

        <div className="rounded-lg border bg-card">
          <div className="p-6">
            <ProductGrid products={products} isLoading={isLoading} />
          </div>
        </div>
      </div>
    </div>
  );
}
