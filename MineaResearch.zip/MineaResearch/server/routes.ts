import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { searchSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/products/search", async (req, res) => {
    try {
      const params = searchSchema.parse(req.query);
      const products = await storage.searchProducts(params);
      res.json(products);
    } catch (err) {
      if (err instanceof ZodError) {
        res.status(400).json({ message: "Invalid search parameters" });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/products/trending", async (_req, res) => {
    try {
      const trendingProducts = await storage.getTrendingProducts();
      res.json(trendingProducts);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch trending products" });
    }
  });

  app.get("/api/products/recent", async (_req, res) => {
    try {
      const recentProducts = await storage.getRecentlyViewedProducts();
      res.json(recentProducts);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch recent products" });
    }
  });

  app.get("/api/products/favorites", async (_req, res) => {
    try {
      const favoriteProducts = await storage.getFavoriteProducts();
      res.json(favoriteProducts);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch favorite products" });
    }
  });

  app.post("/api/products/:id/favorite", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      await storage.addToFavorites(id);
      res.json({ message: "Product added to favorites" });
    } catch (err) {
      res.status(500).json({ message: "Failed to add to favorites" });
    }
  });

  app.delete("/api/products/:id/favorite", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      await storage.removeFromFavorites(id);
      res.json({ message: "Product removed from favorites" });
    } catch (err) {
      res.status(500).json({ message: "Failed to remove from favorites" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid product ID" });
    }

    const product = await storage.getProduct(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    res.json(product);
  });

  app.get("/api/analytics", async (_req, res) => {
    try {
      const analytics = await storage.getAnalytics();
      res.json(analytics);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}