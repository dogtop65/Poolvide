import { products, favorites, type Product, type InsertProduct, type SearchParams } from "@shared/schema";
import { format, subDays } from "date-fns";

// More realistic product titles and descriptions
const PRODUCT_TITLES = [
  "Smart Home Security Camera",
  "Wireless Earbuds Pro",
  "Organic Skincare Set",
  "Smart Fitness Watch",
  "Designer Leather Bag",
  "Portable Power Bank",
  "Premium Coffee Maker",
  "Bluetooth Speaker",
  "Yoga Mat Premium",
  "LED Ring Light",
];

const DESCRIPTIONS = [
  "Professional-grade HD camera with night vision and motion detection. Perfect for home security.",
  "Experience crystal-clear sound with active noise cancellation and 24-hour battery life.",
  "All-natural, vegan-friendly skincare collection made with organic ingredients.",
  "Track your fitness goals with heart rate monitoring and sleep tracking.",
  "Handcrafted genuine leather bag with modern design and ample storage.",
  "Fast-charging 20000mAh power bank with USB-C and wireless charging.",
  "Barista-quality coffee maker with programmable settings and thermal carafe.",
  "Waterproof portable speaker with deep bass and 360° sound.",
  "Extra thick eco-friendly yoga mat with perfect grip and alignment lines.",
  "Professional LED ring light with adjustable brightness and color temperature.",
];

const MOCK_PRODUCTS: Product[] = Array.from({ length: 100 }, (_, i) => ({
  id: i + 1,
  title: PRODUCT_TITLES[i % PRODUCT_TITLES.length] + ` ${Math.floor(i / PRODUCT_TITLES.length) + 1}`,
  description: DESCRIPTIONS[i % DESCRIPTIONS.length],
  price: Math.floor(Math.random() * 20000) + 999, // Prices between $9.99 and $209.99
  platform: ["Amazon", "Facebook", "Instagram", "TikTok"][Math.floor(Math.random() * 4)],
  category: ["Electronics", "Fashion", "Home", "Beauty"][Math.floor(Math.random() * 4)],
  imageUrl: `https://picsum.photos/seed/${i + 1}/400/300`,
  views: Math.floor(Math.random() * 50000) + 1000,
  clicks: Math.floor(Math.random() * 5000) + 100,
  startDate: format(subDays(new Date(), Math.floor(Math.random() * 30)), 'yyyy-MM-dd'),
  isActive: Math.random() > 0.1,
}));

export interface IStorage {
  searchProducts(params: SearchParams): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getTrendingProducts(): Promise<Product[]>;
  getFavoriteProducts(): Promise<Product[]>;
  addToFavorites(productId: number): Promise<void>;
  removeFromFavorites(productId: number): Promise<void>;
  getRecentlyViewedProducts(): Promise<Product[]>;
  getAnalytics(): Promise<{
    totalProducts: number;
    totalViews: number;
    totalClicks: number;
    platformCounts: Record<string, number>;
  }>;
}

export class MemStorage implements IStorage {
  private products: Product[];
  private favorites: Set<number>;
  private recentlyViewed: number[];
  private MAX_RECENT = 10;
  private rotatingPlatformIndex = 0;
  private lastRotation = Date.now();
  private ROTATION_INTERVAL = 5000; // 5 seconds

  constructor() {
    this.products = MOCK_PRODUCTS;
    this.favorites = new Set();
    this.recentlyViewed = [];
  }

  async searchProducts(params: SearchParams): Promise<Product[]> {
    let results = [...this.products];

    if (params.query) {
      const query = params.query.toLowerCase();
      results = results.filter(p =>
        p.title.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query)
      );
    }

    if (params.platform) {
      results = results.filter(p => p.platform === params.platform);
    }

    if (params.category) {
      results = results.filter(p => p.category === params.category);
    }

    if (params.minPrice !== undefined) {
      results = results.filter(p => p.price >= params.minPrice!);
    }

    if (params.maxPrice !== undefined) {
      results = results.filter(p => p.price <= params.maxPrice!);
    }

    if (params.sortBy) {
      results.sort((a, b) => {
        let aVal: string | number;
        let bVal: string | number;

        switch (params.sortBy) {
          case 'date':
            aVal = a.startDate;
            bVal = b.startDate;
            break;
          case 'price':
            aVal = a.price;
            bVal = b.price;
            break;
          case 'views':
            aVal = a.views;
            bVal = b.views;
            break;
          case 'clicks':
            aVal = a.clicks;
            bVal = b.clicks;
            break;
          default:
            return 0;
        }

        const multiplier = params.sortDir === 'desc' ? -1 : 1;
        return (aVal < bVal ? -1 : 1) * multiplier;
      });
    }

    return results;
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const product = this.products.find(p => p.id === id);
    if (product) {
      // Add to recently viewed
      this.recentlyViewed = [id, ...this.recentlyViewed.filter(viewedId => viewedId !== id)]
        .slice(0, this.MAX_RECENT);
    }
    return product;
  }

  async getTrendingProducts(): Promise<Product[]> {
    return this.products
      .filter(p => p.isActive)
      .sort((a, b) => {
        const aScore = a.views * 0.7 + a.clicks * 0.3;
        const bScore = b.views * 0.7 + b.clicks * 0.3;
        return bScore - aScore;
      })
      .slice(0, 12);
  }

  async getRecentlyViewedProducts(): Promise<Product[]> {
    return this.recentlyViewed
      .map(id => this.products.find(p => p.id === id))
      .filter((p): p is Product => p !== undefined);
  }

  async getFavoriteProducts(): Promise<Product[]> {
    return this.products.filter(p => this.favorites.has(p.id));
  }

  async addToFavorites(productId: number): Promise<void> {
    this.favorites.add(productId);
  }

  async removeFromFavorites(productId: number): Promise<void> {
    this.favorites.delete(productId);
  }

  async getAnalytics() {
    const activeProducts = this.products.filter(p => p.isActive);
    const now = Date.now();

    // Rotate platform every 5 seconds
    if (now - this.lastRotation >= this.ROTATION_INTERVAL) {
      this.rotatingPlatformIndex = (this.rotatingPlatformIndex + 1) % 4;
      this.lastRotation = now;
    }

    const platforms = ["Amazon", "Facebook", "Instagram", "TikTok"];
    const selectedPlatform = platforms[this.rotatingPlatformIndex];

    // Create platform counts with the selected platform having the highest count
    const platformCounts = platforms.reduce((counts, platform) => {
      counts[platform] = platform === selectedPlatform
        ? Math.floor(Math.random() * 10) + 30 // 30-40 products
        : Math.floor(Math.random() * 15) + 15; // 15-30 products
      return counts;
    }, {} as Record<string, number>);

    return {
      totalProducts: activeProducts.length,
      totalViews: activeProducts.reduce((sum, p) => sum + p.views, 0),
      totalClicks: activeProducts.reduce((sum, p) => sum + p.clicks, 0),
      platformCounts
    };
  }
}

export const storage = new MemStorage();