import { pgTable, text, serial, integer, date, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  platform: text("platform").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url").notNull(),
  views: integer("views").notNull().default(0),
  clicks: integer("clicks").notNull().default(0),
  startDate: date("start_date").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  createdAt: date("created_at").notNull().default(new Date()),
});

export const insertProductSchema = createInsertSchema(products).omit({ 
  id: true,
  views: true,
  clicks: true 
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export const searchSchema = z.object({
  query: z.string().optional(),
  platform: z.string().optional(),
  category: z.string().optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  sortBy: z.enum(['views', 'clicks', 'date', 'price']).optional(),
  sortDir: z.enum(['asc', 'desc']).optional(),
});

export type SearchParams = z.infer<typeof searchSchema>;